# Video downloader for Facebook

![](https://img.shields.io/github/languages/top/elmurzaev/DownloaderFacebook?style=flat-square&label=written%20in%20kotlin) ![GitHub repo size](https://img.shields.io/github/repo-size/elmurzaev/DownloaderFacebook?style=flat-square) ![Lines of code](https://img.shields.io/tokei/lines/github/elmurzaev/DownloaderFacebook?label=total%20lines%20of%20code&style=flat-square) ![GitHub](https://img.shields.io/github/license/elmurzaev/DownloaderFacebook?style=flat-square)


![GitHub issues](https://img.shields.io/github/issues/elmurzaev/DownloaderFacebook?style=flat-square) ![GitHub pull requests](https://img.shields.io/github/issues-pr/elmurzaev/DownloaderFacebook?style=flat-square) ![GitHub last commit](https://img.shields.io/github/last-commit/elmurzaev/DownloaderFacebook?style=flat-square) 

------------

Simple video downloader for Facebook.

Copy the link of the video from facebook and paste it in the app, then click download icon! Even private videos can be downloaded! The video will be saved right to your gallery!


## Screenshots
_Missing_


## Download
<a href='https://play.google.com/store/apps/details?id=com.elmurzaev.downloader.facebook'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' width=300></a>
