package com.elmurzaev.downloader.facebook

import com.elmurzaev.downloader.facebook.BuildConfig.APPLICATION_ID

const val PRIVACY_URL = "https://elmurzaev.github.io/privacy"
const val GOOGLE_PLAY_URL = "https://play.google.com/store/apps/details?id=$APPLICATION_ID"
const val GOOGLE_PLAY_URI = "market://details?id=$APPLICATION_ID"
const val NOTIFICATION_CHANNEL_DOWNLOADS = "downloads"
const val INTERSTITIAL_UNIT_ID = "ca-app-pub-9961237670339903/1376802218"
const val PACKAGE_FACEBOOK = "com.facebook.katana"
const val PACKAGE_FACEBOOK_LITE = "com.facebook.lite"