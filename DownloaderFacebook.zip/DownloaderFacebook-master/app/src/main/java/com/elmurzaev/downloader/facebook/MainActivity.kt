package com.elmurzaev.downloader.facebook

import android.Manifest
import android.app.DownloadManager
import android.app.ProgressDialog
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.preference.PreferenceManager
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.net.toUri
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.elmurzaev.downloader.facebook.databinding.ActivityMainBinding
import com.elmurzaev.downloader.facebook.extensions.fileExists
import com.elmurzaev.downloader.facebook.extensions.isAppInstalled
import com.google.android.gms.ads.AdRequest
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.play.core.review.ReviewManagerFactory
import es.dmoral.toasty.Toasty.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var preferences: SharedPreferences
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var downloadManager: DownloadManager
    private lateinit var callback: () -> Unit
    private val cookie
        get() = CookieManager.getInstance().getCookie("https://facebook.com").orEmpty()

    private val downloadLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it || Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            callback()
        } else {
            error(this, "Permission denied").show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        preferences = PreferenceManager.getDefaultSharedPreferences(this)
        clipboardManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        downloadManager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager

        setupInputField()
        handleIntent()
        binding.adView.loadAd(AdRequest.Builder().build())
    }

    private fun setupInputField() {
        binding.inputText.doAfterTextChanged { text ->
            text.toString().let {
                when {
                    it.isEmpty() -> {
                        binding.inputLayout.error = null
                        toggleEndIconMode("paste")
                    }
                    isFacebookVideoUrl(it) -> {
                        toggleEndIconMode("download")
                    }
                    else -> {
                        binding.inputLayout.error = "Not supported URL!"
                        binding.inputLayout.setStartIconDrawable(R.drawable.ic_clear)
                        binding.inputLayout.setStartIconOnClickListener { binding.inputText.text?.clear() }
                    }
                }
            }
        }
        binding.inputText.setOnFocusChangeListener { view, hasFocus ->
            if (hasFocus.not()) {
                hideKeyboard(view)
            }
        }
        toggleEndIconMode("paste")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.about -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.share -> Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, getString(R.string.share_app_text, GOOGLE_PLAY_URL))
                startActivity(Intent.createChooser(this, "Share"))
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun handleIntent() {
        intent.dataString?.let {
            binding.inputText.setText(it)
            download(getUrlFromInput())
        }
        intent.getStringExtra(Intent.EXTRA_TEXT)?.let {
            binding.inputText.setText(it)
            download(getUrlFromInput())
        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        checkUpdate()
        rateApp()

        if (preferences.getBoolean("isIntroduced", false).not()) {
            help()
        }
    }

    private fun checkUpdate() {
        val appUpdateManager = AppUpdateManagerFactory.create(this)
        appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo: AppUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
            ) {
                appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo, AppUpdateType.IMMEDIATE, this, 1
                )
            }
        }
    }

    private fun toggleEndIconMode(onto: String) {
        binding.inputLayout.apply {
            if (onto != "clear" && endIconMode != TextInputLayout.END_ICON_CUSTOM) {
                endIconMode = TextInputLayout.END_ICON_CUSTOM
            }
            when (onto) {
                "download" -> {
                    binding.inputLayout.error = null
                    setEndIconDrawable(R.drawable.ic_download)
                    setEndIconOnClickListener {
                        download(getUrlFromInput())
                    }
                    setStartIconDrawable(R.drawable.ic_clear)
                    setStartIconOnClickListener { binding.inputText.text?.clear() }
                }
                "paste" -> {
                    setEndIconDrawable(R.drawable.ic_paste)
                    setEndIconOnClickListener {
                        if (clipboardManager.hasPrimaryClip()) {
                            binding.inputText.setText(
                                clipboardManager.primaryClip?.getItemAt(0)?.text
                            )
                        } else {
                            warning(this@MainActivity, "Nothing to paste!").show()
                        }
                    }
                    setStartIconDrawable(0)
                }
                else -> {
                    endIconMode = TextInputLayout.END_ICON_CLEAR_TEXT
                }
            }
        }
    }

    private fun download(url: String) {
        // init dialog
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Extracting info")
        progressDialog.setButton("Cancel") { dialog, _ ->
            dialog.dismiss()
            lifecycleScope.coroutineContext.cancelChildren()
            warning(this, "Canceled").show()
        }
        progressDialog.setCancelable(false)
        progressDialog.show()

        // async download
        lifecycleScope.launchWhenResumed {
            try {
                // fetch document
                val document = withContext(Dispatchers.IO) {
                    Jsoup.connect(url)
                        .userAgent("Facebook")
                        .header("Cookie", cookie)
                        .get()
                }
                // parse document
                document.apply {
                    val videoUrl = select("meta[property=og:video:url]")
                        .attr("content")
                    val videoTitle = select("meta[property=og:title]")
                        .attr("content")
                    val videoType = select("meta[property=og:video:type]")
                        .attr("content")

                    // construct file name for the video
                    val fileName = "$videoTitle.${videoType.removePrefix("video/")}"

                    if (videoUrl.isEmpty() && cookie.contains("c_user").not()) {
                        // maybe auth required, let the user decide whether to sign-in or not
                        Snackbar.make(
                            binding.root, "Maybe authorization required!",
                            Snackbar.LENGTH_LONG
                        )
                            .setAction("Sign in") { signIn() }
                            .show()
                        callback = { download(url) }
                        return@apply
                    } else if (videoUrl.isNotEmpty()) {
                        callback = {
                            if (fileExists(fileName)) {
                                warning(this@MainActivity, "File exists").show()
                            } else {
                                val request = DownloadManager.Request(videoUrl.toUri())
                                    .addRequestHeader("User-Agent", "Facebook")
                                    .addRequestHeader("Cookie", cookie)
                                    .setTitle(fileName)
                                    .setMimeType(videoType)
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(
                                        Environment.DIRECTORY_MOVIES,
                                        "Facebook/$fileName"
                                    )
                                request.allowScanningByMediaScanner()
                                startDownloadTracking(downloadManager.enqueue(request))
                            }
                        }
                        downloadLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                progressDialog.dismiss()
            }
        }
    }

    private fun startDownloadTracking(id: Long) {
        val progressDialog = ProgressDialog(this)
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
        progressDialog.setMessage("Downloading")
        val listener: (dialog: DialogInterface, which: Int) -> Unit = { dialog, which ->
            if (which == DialogInterface.BUTTON_NEGATIVE) {
                lifecycleScope.coroutineContext.cancelChildren()
                info(this, "Download canceled").show()
                downloadManager.remove(id)
            }
            dialog.dismiss()
        }
        progressDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Hide", listener)
        progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", listener)
        progressDialog.max = 100
        progressDialog.show()

        lifecycleScope.launchWhenResumed {
            do {
                downloadManager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
                    cursor.moveToFirst()
                    // column indexes
                    val columnStatus = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                    val columnBytesDownloaded = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                    val columnTotalBytes = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)

                    // detect status of progress
                    when (cursor.getInt(columnStatus)) {
                        DownloadManager.STATUS_RUNNING -> {
                            val bytesDownloaded = cursor.getInt(columnBytesDownloaded)
                            val bytesToDownload = cursor.getInt(columnTotalBytes)
                            progressDialog.progress = bytesDownloaded * 100 / bytesToDownload
                        }
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            progressDialog.dismiss()
                            success(this@MainActivity, "Download completed!").show()
                            return@launchWhenResumed
                        }
                        DownloadManager.STATUS_FAILED -> {
                            progressDialog.dismiss()
                            error(this@MainActivity, "Could not download!").show()
                            return@launchWhenResumed
                        }
                        else -> return@launchWhenResumed
                    }
                }
                delay(1000)
            } while (true)
        }
    }

    fun openFacebook(view: View) {
        when {
            packageManager.isAppInstalled(PACKAGE_FACEBOOK) -> {
                startActivity(packageManager.getLaunchIntentForPackage(PACKAGE_FACEBOOK))
            }
            packageManager.isAppInstalled(PACKAGE_FACEBOOK_LITE) -> {
                startActivity(packageManager.getLaunchIntentForPackage(PACKAGE_FACEBOOK_LITE))
            }
            else -> {
                startActivity(Intent(Intent.ACTION_VIEW, "https://www.facebook.com/watch/".toUri()))
            }
        }
    }

    private fun signIn() {
        val webView = WebView(this).apply {
            webViewClient = WebViewClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            loadUrl("https://www.facebook.com/login/")
        }

        val dialog = MaterialAlertDialogBuilder(this).setView(webView).show()
        dialog.window!!.clearFlags(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM
        )

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (cookie.contains("c_user")) {
                    dialog.dismiss()
                    info(this@MainActivity, "Signed in").show()
                    callback() // start downloading again
                }
            }
        }
    }

    private fun help() {
        MaterialAlertDialogBuilder(this)
            .setTitle("How to use?")
            .setMessage(
                """
                There are two possible ways:
                1. Input (paste) link into the text field and click the download icon
                2. Share link to this app from any other app (Facebook or website),
                download will start automatically.
            """.trimIndent()
            )
            .setPositiveButton("OK") { _, _ ->
                preferences.edit { putBoolean("isIntroduced", true) }
            }
            .setCancelable(false)
            .show()
    }

    private fun rateApp() {
        val manager = ReviewManagerFactory.create(this)
        manager.requestReviewFlow().addOnSuccessListener {
            manager.launchReviewFlow(this, it)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        this.intent = intent
        handleIntent()
    }

    private fun getUrlFromInput(): String {
        val url = binding.inputText.text.toString()
            .replaceAfter("?", "")
            .removeSuffix("?")
            .replace("/m.", "/")
        return if (isFacebookVideoUrl(url)) {
            if (URLUtil.isNetworkUrl(url)) {
                url
            } else {
                "https://$url"
            }
        } else {
            ""
        }
    }
}