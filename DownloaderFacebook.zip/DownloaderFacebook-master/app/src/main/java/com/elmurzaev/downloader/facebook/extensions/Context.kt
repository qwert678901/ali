package com.elmurzaev.downloader.facebook.extensions

import android.content.Context
import android.content.res.Configuration
import android.provider.MediaStore

fun Context.isNightMode() = resources.configuration.uiMode and
        Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES

fun Context.fileExists(name: String): Boolean {
    contentResolver.query(
        MediaStore.Files.getContentUri("external"),
        arrayOf(MediaStore.MediaColumns._ID),
        "${MediaStore.MediaColumns.DISPLAY_NAME} = ?",
        arrayOf(name),
        null
    )?.use {
        return it.count != 0
    }
    return false
}