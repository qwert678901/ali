package com.elmurzaev.downloader.facebook.extensions

import android.content.pm.PackageManager
import com.elmurzaev.downloader.facebook.PACKAGE_FACEBOOK
import com.elmurzaev.downloader.facebook.PACKAGE_FACEBOOK_LITE

fun PackageManager.isAppInstalled(packageName: String): Boolean = try {
    getApplicationInfo(packageName, PackageManager.GET_META_DATA)
    true
} catch (e: PackageManager.NameNotFoundException) {
    false
}

fun PackageManager.isFacebookInstalled() =
    isAppInstalled(PACKAGE_FACEBOOK) or isAppInstalled(PACKAGE_FACEBOOK_LITE)
