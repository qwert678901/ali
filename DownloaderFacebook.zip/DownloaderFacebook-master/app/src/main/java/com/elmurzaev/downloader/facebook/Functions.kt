package com.elmurzaev.downloader.facebook

import android.app.Activity
import android.view.View
import android.view.inputmethod.InputMethodManager

/**
 * whether ot not the given url is valid against this regex:
 * (?:https?://)?(?:www\.)?(?:m\.)?facebook.com/.+?/videos/.+
 * @param url the url to check
 * */
fun isFacebookVideoUrl(url: String): Boolean {
    return """(?:https?://)?(?:www\.)?(?:m\.)?facebook.com/.+?/.+?/.+""".toRegex().matches(url)
}

fun hideKeyboard(view: View) {
    val context = view.context
    val manager = context.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
    manager.hideSoftInputFromWindow(view.windowToken, 0)
}